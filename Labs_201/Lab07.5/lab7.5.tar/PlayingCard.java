public class PlayingCard {

    public static void main (String [] args) {

	// write your code below and then enter the following
	// rank-suit pairs
	// 9 S
	// 2 H
	// 6 C
	// J D
	// Q S
	// 10 C
	// K H
	// A D

    }
}