public class CumulativeProduct {

    public static void main (String [] args) {
	// enter 4 and then the values: 7 2 3 15 You should get 630
	// enter 7 and then the values: 2 1 4 3 -1 5 10 You should get -1200
	// enter 1 and then the value: 42 You should get 42

	// put your code segment here

    }




}