

public class Demo1 {

    public static void main (String [] args) {
 
        // Short version
        // code here

        // Long version
        // code here

    }

}
