import java.util.*;
import java.io.*;

public class Demo3 {

    public static void main (String [] args) throws FileNotFoundException{
	Scanner sc = new Scanner(new File("data.txt"));
        // get the number of values
	int size = sc.nextInt();
	//        double [] a = readArray(sc, size);
	//        double average = average(a);
	//	System.out.println("Average = " + average);
	//	System.out.println("The largest value in the data set is: " +
	//			   max(a));
    }

    // put readArray() here and modify it as required

    
    // write average() here


    // write max() here

}
