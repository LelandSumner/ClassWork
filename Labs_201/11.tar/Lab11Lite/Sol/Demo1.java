

public class Demo1 {

    public static void main (String [] args) {
 
        // Short version
        // code here
        double [] a = {4.2, 18.0, 3.4, 9.1, 13.2};

        // Long version
        // code here
	double [] b = new double[5];
	b[0] = 4.2;
	b[1] = 18;
	b[2] = 3.4;
	b[3] = 9.1;
	b[4] = 13.2;

    }

}
