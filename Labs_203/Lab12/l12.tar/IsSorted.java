public class IsSorted {

    public static void main (String [] args) {
	double [] t1 = {16.1, 12.3, 22.2, 14.4};
	System.out.println(isSorted(t1));
	double [] t2 = {1.5, 4.3, 7.0, 19.5, 25.1, 46.2};
	System.out.println(isSorted(t2));
	double [] t3 = {42.0};
	System.out.println(isSorted(t3));
	double [] t4 = {42.0, 27.0};
	System.out.println(isSorted(t4));
        double [] t5 = {1.5, 4.3, 7.0, 19.5, 7.8, 25.1, 46.2};
	System.out.println(isSorted(t5));
    }

    // write isSorted here



}
