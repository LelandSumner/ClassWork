import java.util.*;

public class MinGap {

    public static void main (String [] args) {
	int [] a = {2, 4, 6};
	System.out.println(minGap(a));
	int [] b = {};
	System.out.println(minGap(b));
	int [] c = {88};
	System.out.println(minGap(c));
	int [] d = {1, 3, 6, 7, 12};
	System.out.println(minGap(d));
	int [] e = {3, 5, 11, 4, 8, 10};
	System.out.println(minGap(e));

    }

    // write minGap here


}
